Manual de execução

No terminal digite:
1. make
2. ./Ex01_1 (Siga as instruções do terminal
3. ./Ex01_2 (Siga as instruções do terminal
4. ./Ex01_3 “DIGITE_A_PALAVRA_A_SER_TESTADA_COMO_PALÍNDROMO”
	ex: ./Ex01_3 “ROMA ME TEM AMOR”
5. ./Ex01_4 (Assista a magia do array acontecer)
6. ./Ex01_5 (Assista a magia do for acontecer)
7. make clean