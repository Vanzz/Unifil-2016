//
//  forca.h
//  forca
//
//  Created by Ricardo Inácio Álvares e Silva on 23/02/15.
//  Copyright (c) 2015 Ricardo Inácio Álvares e Silva. All rights reserved.
//

#ifndef __forca__forca__
#define __forca__forca__

void jogar_forca(char const * palavra);

#endif /* defined(__forca__forca__) */
