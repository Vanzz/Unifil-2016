import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
/**
 * Write a description of class Pessoa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pessoa extends Actor
{
    /**
     * Act - do whatever the Pessoa wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       //label.drawString("Teste", 100, 100);
       
       // Add your action code here.
    }
    
    public String toString() {
        return "";
    }
}
